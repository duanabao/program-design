#include<iostream>
using namespace std;
struct node
{
	int data;
	node* next;
};
node* create(int Array[],int n)
{
	node *head,*pre,*p;
	head=new node;
	head->data=Array[1];
	head->next=NULL;
	pre=head;
	for(int i=2;i<=n;i++)
	{
		p=new node;
		p->data=Array[i];
		p->next=NULL;
		pre->next=p;
		pre=p;
	}
	pre->next=head;
	return head;
}
void find(node *head,int m)
{
	node *pre=head;
	while(pre->next!=head)
	   pre=pre->next;//��ͷ������һ���
	node *p=head;
	while(p->next!=p) 
	{
		for(int i=1;i<m;i++)
		{
			pre=p;
			p=p->next;
		}
		pre->next=p->next;
		delete p;
		p=pre->next; 
	}
	cout<<p->data;
	delete p;
}
int a[10010];
int main()
{
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	  a[i]=i;
	node* head=create(a,n);
	find(head,m);
	return 0;
 } 
