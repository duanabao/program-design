#include<iostream>
using namespace std;
bool f[100010];
int main()
{
	int n,m;
	cin>>n>>m;
	int sum=0;
	int loc=0;
	int num=0;
	while(sum!=n)
	{
		loc++;
		if(loc>n)
		  loc=1;
		if(f[loc]==0) 
		   num++;
	    if(num==m)
	    {
	    	num=0;
	    	if(sum==n-1)
	    	  cout<<loc;
	    	f[loc]=1;
	    	sum++;
		}
	}
	return 0;
 } 
