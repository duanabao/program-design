#include<iostream>
#include<queue>
using namespace std;
queue<int> Q;
int main()
{
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	  Q.push(i);
	while(Q.size()>1)
	{
		for(int i=1;i<m;i++)
		{
			int c=Q.front();
			Q.pop();
			Q.push(c);
		}
		Q.pop();
	}
	cout<<Q.front();
	return 0;
 } 
