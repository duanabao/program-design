/*
insert x ��ͷ���Ӽ�ֵx�Ľ��
delete x ɾ����һ�����м�ֵx�Ľ��
deleteFirst ɾ��ͷ���
deleteLast ɾ��β��� 
*/
#include<iostream>
#include<string.h>
using namespace std;
struct Node
{
	int key;
	Node *next,*prev;
};
Node *nil;
Node* listSearch(int key)
{
	Node *p=nil->next;
	while(p!=nil&&p->key!=key)
	  p=p->next;
	return p;
}
void init()
{
	 nil=new Node;
	 nil->next=nil;
	 nil->prev=nil;
 } 
void printList()
{
	Node *p=nil->next;
	int isf=0;
	while(1)
	{
		if(p==nil)
		   break;
		if(isf++>0)
		   cout<<" ";
		cout<<p->key;
		p=p->next;
	}
}
void deleteNode(Node *t)
{
	if(t==nil)
	   return;
	t->prev->next=t->next;
	t->next->prev=t->prev;
	delete t;
} 
void deleteFirst()
{
	deleteNode(nil->prev);
}
void deleteLast()
{
	deleteNode(nil->prev);
}
void deleteKey(int key)
{
	deleteNode(listSearch(key));
}
void insert(int key)
{
	Node *x=new Node;
	x->key=key;
	x->next=nil->next;
	nil->next->prev=x;
	nil->next=x;
	x->prev=nil;
}
int main()
{
	int key,n,i;
	int size=0;
	char com[20];
	int np=0,nd=0;
	cin>>n;
	init();
	for(i=0;i<n;i++)
	{
		cin>>com>>key;
		if(com[0]=='i')
		{
			insert(key);
			np++;
			size++;
		}
		else if(com[0]=='d')
		{
			if(strlen(com)>6)
			{
				if(com[6]=='F')
				  deleteFirst();
				else if(com[6]=='L')
				   deleteLast();
			}
			else 
			{
				deleteKey(key);
				nd++;
			}
			size--;
		}
	}
	printList();
	return 0;
}
/*
����
7
insert 5
insert 2
insert 3
insert 1
delete 3
insert 6
delete 5
���
6 1 2 
*/ 
