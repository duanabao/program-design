#pragma once
#include "BaseObject.h"
class Bullet:
    public BaseObject
{
};

